package com.almalik.firstprg.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.almalik.firstprg.entity.User;
import com.almalik.firstprg.exception.FileException;
import com.almalik.firstprg.service.UserServiceInterface;

@Controller
@RequestMapping("api/user")
public class UserController extends FileException{

	@Autowired
	private UserServiceInterface  userServiceInterface;
	
	@RequestMapping(value = "/create" ,method = RequestMethod.POST)
	@ResponseBody
	public User create(@RequestBody User user) throws Throwable{
		return userServiceInterface.create(user);
	}
}
