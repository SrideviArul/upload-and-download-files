package com.almalik.firstprg.entity;

import java.io.File;
import java.util.List;
import java.util.UUID;

import org.springframework.web.multipart.MultipartFile;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Transient;

/**
 * File details in customer entity
 */
@Entity
public class FileEntity {

	/** Customer **/
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String name;

	private String address;
	
	private UUID randomUUID = UUID.randomUUID();

	public UUID getRandomUUID() {
		return randomUUID;
	}

	public void setRandomUUID(UUID randomUUID) {
		this.randomUUID = randomUUID;
	}

	@Column(name = "email", columnDefinition = "varchar(30)")
	private String email;

	private String fileName;

	@Transient
	private MultipartFile[] file;

	private String link;
	
	@Column(name="user_id")
	private Long userId;
	
	@OneToOne
	@JoinColumn(name="user_id",referencedColumnName = "id" , insertable = false,updatable = false)
	private User user;
	
	public String getLink() {
		return link;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public void setLink(String link) {
		this.link = link;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public MultipartFile[] getFile() {
		return file;
	}

	public void setFile(MultipartFile[] file) {
		this.file = file;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the randomUUID
	 */

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName the fileName to set
	 * @return
	 */
	public String setFileName(String fileName) {
		return this.fileName = fileName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


}
