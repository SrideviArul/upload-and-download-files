package com.almalik.firstprg.exception;

import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ExceptionHandler;

public class FileException {
                                                                 
    @ExceptionHandler
	@ResponseBody
	public String HandlerException(CustomException ex) {
		return ex.getErrorMessage();
		
	}
	
	}
	
	

