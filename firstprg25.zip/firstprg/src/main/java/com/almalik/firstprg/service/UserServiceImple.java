package com.almalik.firstprg.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.almalik.firstprg.Repository.UserRepo;
import com.almalik.firstprg.entity.User;

@Service
public class UserServiceImple  implements UserServiceInterface{

	@Autowired
	private UserRepo userRepo;
	
	@Override
	public User create(User user) throws Throwable {
		user.setStatus(true);
		user.setCreatedBy(LocalDateTime.now());
		return userRepo.save(user);
	}

}
