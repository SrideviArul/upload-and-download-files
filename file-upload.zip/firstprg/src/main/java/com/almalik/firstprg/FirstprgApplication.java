package com.almalik.firstprg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstprgApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstprgApplication.class, args);
	}

}
