package com.almalik.firstprg.exception;

public class CustomException extends RuntimeException{
	
    private String errorMessage;
     
	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public CustomException(String message) {
	        this.errorMessage = message;
	    }


}
