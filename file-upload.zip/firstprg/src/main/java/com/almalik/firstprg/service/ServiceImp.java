package com.almalik.firstprg.service;
import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.apache.tika.Tika;
import org.apache.tika.config.TikaConfig;
import org.apache.tika.mime.MimeType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.almalik.firstprg.Repository.ServiceRepo;
import com.almalik.firstprg.entity.FileEntity;
import com.almalik.firstprg.exception.CustomException;

@Service
public class ServiceImp implements ServiceInterface {

	@Value("${spring.file.upload-dir}")
	private String uploadDir;

	@Autowired
	ServiceRepo serviceRepo;

	UUID randomUUID = UUID.randomUUID();

	@Override
	public List<FileEntity> upladFile(FileEntity fe) throws Throwable {
		List<FileEntity> fileReturn = new ArrayList<>();
		MultipartFile[] d = fe.getFile();
		for (MultipartFile gh : d) {
			FileEntity obj = new FileEntity();
			if (fe == null) {
				throw new CustomException("it is empty");
			}
			List<String> extension = Arrays.asList("jpeg", "jpg", "png", "avif");
			String originalFilename = gh.getOriginalFilename();
			String fileExtension = originalFilename.substring(originalFilename.lastIndexOf(".") + 1).toLowerCase();
			if (!extension.contains(fileExtension)) {
				throw new CustomException("Invalid file type. Allowed types: jpg, jpeg, png, avif");
			}
			Tika tikaObj = new Tika();
			String finder = tikaObj.detect(gh.getInputStream());
			MimeType mime = TikaConfig.getDefaultConfig().getMimeRepository().forName(gh.getContentType());
			String extentionType = mime.getExtension();
			if (!(finder.equals(gh.getContentType()))) {
				throw new CustomException(gh.getOriginalFilename() + " " + "please upload correct file");
			}
			if (fe.getEmail().isEmpty() || !isValidEmail(fe.getEmail())) {
				throw new CustomException(fe.getEmail() + " " + "Invalid Email");
			}
			String uidExtention = obj.getRandomUUID() + extentionType;
			String fileName = obj.setFileName(uidExtention);
			obj.setName(fe.getName());
			obj.setAddress(fe.getAddress());
			obj.setEmail(fe.getEmail());
			obj.setLink(uploadDir + fileName);
			gh.transferTo(new File(uploadDir + obj.getFileName()));
			serviceRepo.save(obj);
			fileReturn.add(obj);
		}
		return fileReturn;
	}

	private boolean isValidEmail(String email) {
		String regex = "^[a-z0-9]{5,15}+@[a-z]{2,5}+.[a-z]{2,3}$";
		return email.matches(regex);
	}

	@Override
	public ResponseEntity<Resource> download(String fileName) throws Throwable {
		Path filePath = Paths.get("location", fileName);
		Resource resource = new UrlResource(filePath.toUri());
		if (resource.exists()) {
			HttpHeaders headers = new HttpHeaders();
			headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName);
			return ResponseEntity.ok().headers(headers).body(resource);
		} else {
			throw new CustomException("File not found: " + fileName);
		}
	}
}
