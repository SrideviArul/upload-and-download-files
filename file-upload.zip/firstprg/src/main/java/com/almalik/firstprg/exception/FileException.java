package com.almalik.firstprg.exception;

import org.springframework.web.bind.annotation.ResponseBody;

public class FileException {

	@org.springframework.web.bind.annotation.ExceptionHandler
	@ResponseBody
	public String HandlerException(CustomException ex) {
		return ex.getErrorMessage();
		
	}
	
	}
	
	

